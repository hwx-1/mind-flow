package com.mental.health.service;

import com.mental.health.common.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Set;
import java.util.UUID;

@Slf4j
@Service
public class UploadService {

    @Value("${upload.path}")        private String uploadPath;
    @Value("${upload.url-prefix}")  private String urlPrefix;

    private static final Set<String> IMG = Set.of("jpg", "jpeg", "png", "gif", "webp", "bmp");
    private static final Set<String> VID = Set.of("mp4", "mov", "m4v", "webm", "avi");

    public String image(MultipartFile f) { return save(f, "img", IMG, 50); }
    public String video(MultipartFile f) { return save(f, "video", VID, 200); }

    private String save(MultipartFile file, String sub, Set<String> allow, int maxMb) {
        if (file == null || file.isEmpty()) throw new BizException("文件为空");
        if (file.getSize() > maxMb * 1024L * 1024L) throw new BizException("文件超过 " + maxMb + "MB");
        String ext = FilenameUtils.getExtension(file.getOriginalFilename()).toLowerCase();
        if (!allow.contains(ext)) throw new BizException("不支持的格式: " + ext);

        String day = LocalDate.now().toString();
        Path dir = Paths.get(uploadPath, sub, day);
        try {
            Files.createDirectories(dir);
            String fn = UUID.randomUUID().toString().replace("-", "") + "." + ext;
            Path dest = dir.resolve(fn);
            file.transferTo(dest.toFile());
            return String.format("%s/%s/%s/%s", urlPrefix, sub, day, fn);
        } catch (IOException e) {
            log.error("upload fail", e);
            throw new BizException("上传失败");
        }
    }
}
