package com.mental.health.controller;

import com.mental.health.common.R;
import com.mental.health.service.UploadService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/upload")
@RequiredArgsConstructor
public class UploadController {

    private final UploadService uploadService;

    @PostMapping("/image")
    public R<Map<String, String>> image(@RequestPart("file") MultipartFile file) {
        return R.ok(Map.of("url", uploadService.image(file)));
    }

    @PostMapping("/video")
    public R<Map<String, String>> video(@RequestPart("file") MultipartFile file) {
        return R.ok(Map.of("url", uploadService.video(file)));
    }
}
